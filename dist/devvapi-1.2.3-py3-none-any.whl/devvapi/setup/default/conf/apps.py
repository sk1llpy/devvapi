INSTALLED_APPS = [
    # Register your apps here.

    # Example: 'version.app_name' | 'v1.users'
]