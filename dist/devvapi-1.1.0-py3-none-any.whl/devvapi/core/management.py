def execute_command(argv):
    if len(argv) == 2:
        if argv[1] == '--runserver':
            run()