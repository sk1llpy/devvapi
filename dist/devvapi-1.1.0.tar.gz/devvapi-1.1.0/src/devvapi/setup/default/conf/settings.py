SECRET_KEY = 'devvapi-secret-(___random__secret__key___)'

LANGUAGE_CODE = 'en'

TIME_ZONE = 'UTC'
USE_TZ = True

HOST = 'localhost:8000'

DOCS_URL = '/docs'
REDOC_URL = '/redoc'

PROJECT_NAME = '(___project__name___)'
PROJECT_DESCRIPTION = 'Type description here.'
PROJECT_DEFAULT_VERSION = 1
